
import edu.uci.ics.crawler4j.crawler.Page;
import edu.uci.ics.crawler4j.crawler.WebCrawler;
import edu.uci.ics.crawler4j.parser.HtmlParseData;
import edu.uci.ics.crawler4j.url.WebURL;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;

public class MyCrawler extends WebCrawler {

    private final static Pattern FILTERS = Pattern.compile(".*(\\.(html,php))$");

    //  private final static Pattern FILTERS = Pattern.compile(".*(\\.(css|js|gif|jpg"
    //   + "|png|mp3|mp3|zip|gz|ico))$");
    public boolean shouldVisit(Page referringPage, WebURL url) {

        String href = url.getURL().toLowerCase();
        System.out.println("href: " + href);
        return !FILTERS.matcher(href).matches()
                && href.startsWith("http://www.unal.edu.co/");


    }

    @Override
    public void visit(Page page) {
        String url = page.getWebURL().getURL();
        System.out.println("URL: " + url);

        if (page.getParseData() instanceof HtmlParseData) {
            try {
                HtmlParseData htmlParseData = (HtmlParseData) page.getParseData();
                // String text = htmlParseData.getText();
                String html = htmlParseData.getHtml();
                List<WebURL> links = htmlParseData.getOutgoingUrls();

                //System.out.println("Text length: " + text.length());
                //System.out.println("Html length: " + html.length());

                System.out.println("linkss" + links);
                //System.out.println("Number of outgoing links: " + links.size());

                // if (links == null) {
                //   System.setOut(new PrintStream(new FileOutputStream("urls.txt")));
                //  System.out.println(links);
                //}

                System.setOut(new PrintStream(new FileOutputStream("urls.txt")));
                System.out.println(links);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(MyCrawler.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}